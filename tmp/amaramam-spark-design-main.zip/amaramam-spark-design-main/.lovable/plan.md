

# Amaramam Skill Hub — Website Plan

## Design System
- **Color Palette**: Vibrant purple (#7C3AED) as primary, coral orange (#F97316) as accent, teal (#14B8A6) for highlights, with soft grays and white backgrounds for contrast
- **Typography**: Bold, modern headings with clean body text — strong visual hierarchy throughout
- **Style**: Colorful gradient accents, rounded cards, subtle shadows, smooth hover animations, and playful icons (Lucide)

---

## Pages & Key Sections

### 1. Homepage
- **Hero Section**: Full-width gradient banner with bold headline ("Unlock Your Future with Real-World Skills"), subheadline, and two CTA buttons: "Explore Courses" + "Apply for Training"
- **Stats Bar**: Animated counters — learners trained, courses offered, college partners, success rate
- **Value Proposition**: 3-column icon cards (Wide Course Catalog, Practical Training, Industry Certifications)
- **Featured Courses**: Horizontal scrollable course cards
- **Testimonials Carousel**: Student quotes with photos and ratings
- **CTA Banner**: "Start Your Learning Journey Today" with email signup
- **Navigation**: Sticky top navbar with logo, links (Courses, Programs, About, Blog, Contact), and "Apply Now" button

### 2. Course Catalog
- **Filter Sidebar/Bar**: Category filters (AI/ML, Web Dev, Business, Graphics, Soft Skills), tags (Free, Certification, Online/Offline), and search
- **Course Grid**: Cards with thumbnail image, title, short description, star ratings, duration badge, price, and "Enroll Now" button
- **Sorting**: By popularity, newest, price

### 3. Training & Programs
- **Hero**: Section highlighting college partnerships and summer training
- **Program Cards**: Accordion or tabbed layout for each program showing schedule, benefits, outcomes, eligibility
- **Apply Now Form**: Inline form with name, email, phone, program selection, and message
- **Partner Logos**: Carousel of college/institution logos

### 4. About Us
- **Story Section**: Mission, vision, and founding story with a compelling image
- **Why Choose Us**: 4-column benefits grid with icons
- **Team/Mentors**: Grid of instructor cards with photo, name, title, and short bio

### 5. Testimonials & Success Stories
- **Student Reviews**: Card grid with photo, quote, star rating, and course completed
- **Metrics Section**: Large stat blocks (e.g., "10,000+ Learners", "50+ College Partners")
- **Video Testimonials**: Embedded video cards (placeholder thumbnails)

### 6. Blog / Resources
- **Featured Post**: Large hero-style card at top
- **Blog Grid**: Cards with image, category badge, title, excerpt, date, and "Read More" link
- **Categories Sidebar**: Filter by topic

### 7. Contact / Get in Touch
- **Contact Form**: Name, Email, Phone, Message, Course Interest dropdown
- **Info Cards**: Address, phone, email displayed alongside
- **Map Embed**: Placeholder map section
- **FAQ Accordion**: Common questions and answers

### 8. Global Footer
- **Columns**: Quick Links, Programs, Resources, Contact Info
- **Newsletter**: Email input with subscribe button
- **Social Media Icons**: Row of social links
- **Copyright bar**

---

## UX & Responsiveness
- Fully responsive — mobile-first approach with hamburger menu on small screens
- Clear, consistent CTAs on every page to drive enrollment
- Smooth scroll animations and hover effects for engagement
- All pages use sample/placeholder content with SEO-ready headlines and copy

---

## Technical Approach
- All frontend with React, React Router for multi-page navigation
- No backend needed initially — static content with sample data
- Recharts for any stats/metrics visualizations
- Shadcn UI components for forms, accordions, tabs, cards, and dialogs

