import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import Layout from "@/components/Layout";
import { blogPosts } from "@/data/siteData";

const blogCategories = ["All", "Career Guidance", "Industry News", "Learning Tips"];

const Blog = () => {
  const [selectedCategory, setSelectedCategory] = useState("All");

  const featured = blogPosts.find((p) => p.featured);
  const filtered = blogPosts
    .filter((p) => !p.featured)
    .filter((p) => selectedCategory === "All" || p.category === selectedCategory);

  return (
    <Layout>
      {/* Hero */}
      <section className="bg-gradient-to-br from-primary/10 via-background to-accent/5 px-4 py-12 md:py-16">
        <div className="container mx-auto text-center">
          <h1 className="mb-4 font-display text-4xl font-extrabold text-foreground md:text-5xl">Blog & Resources</h1>
          <p className="mx-auto max-w-2xl text-muted-foreground">
            Insights, tips, and news to fuel your learning journey.
          </p>
        </div>
      </section>

      {/* Featured Post */}
      {featured && (
        <section className="px-4 py-10">
          <div className="container mx-auto">
            <Card className="group overflow-hidden border-none shadow-lg md:flex md:flex-row">
              <div className="h-64 overflow-hidden md:h-auto md:w-1/2">
                <img src={featured.image} alt={featured.title} className="h-full w-full object-cover transition-transform group-hover:scale-105" />
              </div>
              <CardContent className="flex flex-col justify-center p-8 md:w-1/2">
                <Badge className="mb-3 w-fit bg-accent text-accent-foreground">{featured.category}</Badge>
                <h2 className="mb-3 font-display text-2xl font-bold text-foreground md:text-3xl">{featured.title}</h2>
                <p className="mb-4 text-muted-foreground">{featured.excerpt}</p>
                <p className="mb-4 text-sm text-muted-foreground">{featured.date}</p>
                <Button className="w-fit bg-primary text-primary-foreground hover:bg-primary/90">Read More</Button>
              </CardContent>
            </Card>
          </div>
        </section>
      )}

      {/* Category filters + Grid */}
      <section className="px-4 py-10">
        <div className="container mx-auto">
          <div className="mb-8 flex flex-wrap gap-2">
            {blogCategories.map((cat) => (
              <Button
                key={cat}
                size="sm"
                variant={selectedCategory === cat ? "default" : "outline"}
                onClick={() => setSelectedCategory(cat)}
                className={selectedCategory === cat ? "bg-primary text-primary-foreground" : ""}
              >
                {cat}
              </Button>
            ))}
          </div>
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {filtered.map((post) => (
              <Card key={post.id} className="group overflow-hidden border-none shadow-md transition-all hover:shadow-xl hover:-translate-y-1">
                <div className="h-48 overflow-hidden">
                  <img src={post.image} alt={post.title} className="h-full w-full object-cover transition-transform group-hover:scale-105" />
                </div>
                <CardContent className="p-5">
                  <Badge variant="outline" className="mb-2">{post.category}</Badge>
                  <h3 className="mb-2 font-display text-lg font-semibold text-foreground">{post.title}</h3>
                  <p className="mb-3 text-sm text-muted-foreground">{post.excerpt}</p>
                  <p className="text-xs text-muted-foreground">{post.date}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default Blog;
