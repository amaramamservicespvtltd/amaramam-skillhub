import { CheckCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import Layout from "@/components/Layout";
import { programs } from "@/data/siteData";
import programsBanner from "@/assets/programs-banner.jpg";

const Programs = () => {
  return (
    <Layout>
      {/* Hero */}
      <section className="relative overflow-hidden px-4 py-12 md:py-16">
        <img src={programsBanner} alt="Training programs" className="absolute inset-0 h-full w-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-br from-teal/80 via-background/90 to-primary/60" />
        <div className="container relative mx-auto text-center">
          <Badge className="mb-4 bg-teal text-teal-foreground">College Partnerships & Training</Badge>
          <h1 className="mb-4 font-display text-4xl font-extrabold text-foreground md:text-5xl">Training & Programs</h1>
          <p className="mx-auto max-w-2xl text-muted-foreground">
            Partnering with 50+ colleges to deliver industry-ready skills training. From summer programs to weekend workshops.
          </p>
        </div>
      </section>

      {/* Programs */}
      <section className="px-4 py-12">
        <div className="container mx-auto">
          <Accordion type="single" collapsible className="space-y-4">
            {programs.map((prog, i) => (
              <AccordionItem key={i} value={`program-${i}`} className="rounded-lg border bg-card px-6 shadow-sm">
                <AccordionTrigger className="font-display text-lg font-semibold hover:no-underline">
                  {prog.title}
                </AccordionTrigger>
                <AccordionContent>
                  <div className="grid gap-6 pb-4 md:grid-cols-2">
                    <div>
                      <p className="mb-4 text-muted-foreground">{prog.description}</p>
                      <p className="mb-2 text-sm"><strong>Schedule:</strong> {prog.schedule}</p>
                      <p className="mb-2 text-sm"><strong>Eligibility:</strong> {prog.eligibility}</p>
                      <p className="text-sm text-teal font-medium">{prog.outcomes}</p>
                    </div>
                    <div>
                      <h4 className="mb-3 font-semibold text-foreground">Key Benefits</h4>
                      <ul className="space-y-2">
                        {prog.benefits.map((b) => (
                          <li key={b} className="flex items-center gap-2 text-sm text-muted-foreground">
                            <CheckCircle className="h-4 w-4 text-teal" /> {b}
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      </section>

      {/* Apply Form */}
      <section className="bg-muted/30 px-4 py-16">
        <div className="container mx-auto max-w-2xl">
          <h2 className="mb-2 text-center font-display text-3xl font-bold text-foreground">Apply Now</h2>
          <p className="mb-8 text-center text-muted-foreground">Fill in the form below and our team will get back to you within 48 hours.</p>
          <Card className="border-none shadow-lg">
            <CardContent className="space-y-4 p-6">
              <div className="grid gap-4 sm:grid-cols-2">
                <Input placeholder="Full Name" />
                <Input placeholder="Email Address" type="email" />
              </div>
              <div className="grid gap-4 sm:grid-cols-2">
                <Input placeholder="Phone Number" type="tel" />
                <Select>
                  <SelectTrigger><SelectValue placeholder="Select Program" /></SelectTrigger>
                  <SelectContent>
                    {programs.map((p) => <SelectItem key={p.title} value={p.title}>{p.title}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <Textarea placeholder="Tell us about yourself and your goals..." rows={4} />
              <Button className="w-full bg-accent text-accent-foreground hover:bg-accent/90">Submit Application</Button>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Partner logos placeholder */}
      <section className="px-4 py-12">
        <div className="container mx-auto text-center">
          <h3 className="mb-8 font-display text-xl font-semibold text-muted-foreground">Trusted by 50+ Institutions</h3>
          <div className="flex flex-wrap items-center justify-center gap-8 opacity-40">
            {["IIT Delhi", "NIT Trichy", "BITS Pilani", "VIT", "SRM University", "Anna University"].map((name) => (
              <div key={name} className="rounded-lg border bg-muted/50 px-6 py-3 font-display text-sm font-semibold text-foreground">
                {name}
              </div>
            ))}
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default Programs;
