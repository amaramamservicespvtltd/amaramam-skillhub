import Layout from "@/components/Layout";

const PrivacyPolicy = () => {
  return (
    <Layout>
      <section className="bg-gradient-to-br from-primary/10 via-background to-teal/5 px-4 py-12 md:py-16">
        <div className="container mx-auto text-center">
          <h1 className="mb-4 font-display text-4xl font-extrabold text-foreground md:text-5xl">Privacy Policy</h1>
          <p className="mx-auto max-w-2xl text-muted-foreground">Last updated: February 2026</p>
        </div>
      </section>

      <section className="px-4 py-12">
        <div className="container mx-auto max-w-4xl space-y-8 text-foreground">
          <div>
            <h2 className="mb-3 font-display text-2xl font-bold">1. Data Collection</h2>
            <p className="text-muted-foreground">We collect personal information that you voluntarily provide when registering for courses, filling out forms, or contacting us. This includes your name, email address, phone number, educational background, and payment information. We may also automatically collect device information, IP addresses, and browsing behavior through cookies and analytics tools.</p>
          </div>

          <div>
            <h2 className="mb-3 font-display text-2xl font-bold">2. How We Use Your Data</h2>
            <p className="text-muted-foreground">Your data is used to process enrollments, deliver course content, communicate updates, provide customer support, and improve our services. We may also use your information to send promotional materials about new courses and offers — you can opt out at any time. We never sell your personal data to third parties.</p>
          </div>

          <div>
            <h2 className="mb-3 font-display text-2xl font-bold">3. Cookies</h2>
            <p className="text-muted-foreground">Our website uses cookies to enhance your browsing experience, remember your preferences, and analyze site traffic. You can control cookie settings through your browser. Disabling cookies may affect certain features of the website.</p>
          </div>

          <div>
            <h2 className="mb-3 font-display text-2xl font-bold">4. Third-Party Services</h2>
            <p className="text-muted-foreground">We may use third-party services for payment processing, analytics, email communication, and hosting. These providers have their own privacy policies and are bound by data protection agreements. We ensure that any third-party service we use complies with applicable data protection regulations.</p>
          </div>

          <div>
            <h2 className="mb-3 font-display text-2xl font-bold">5. User Rights</h2>
            <p className="text-muted-foreground">You have the right to access, update, correct, or delete your personal data at any time. You may request a copy of the data we hold about you. To exercise any of these rights, please contact us at <a href="mailto:info@amaramam.com" className="text-primary underline hover:text-primary/80">info@amaramam.com</a>. We will respond to your request within 30 days.</p>
          </div>

          <div>
            <h2 className="mb-3 font-display text-2xl font-bold">6. Security Measures</h2>
            <p className="text-muted-foreground">We implement industry-standard security measures including SSL encryption, secure servers, and access controls to protect your personal data. However, no method of transmission over the internet is 100% secure, and we cannot guarantee absolute security.</p>
          </div>

          <div>
            <h2 className="mb-3 font-display text-2xl font-bold">7. Data Retention</h2>
            <p className="text-muted-foreground">We retain your personal data for as long as your account is active or as needed to provide services. After account deletion, we may retain certain data for legal, audit, or legitimate business purposes for a reasonable period.</p>
          </div>

          <div>
            <h2 className="mb-3 font-display text-2xl font-bold">8. Contact for Privacy Queries</h2>
            <p className="text-muted-foreground">For any privacy-related questions or concerns, please reach out to us at <a href="mailto:info@amaramam.com" className="text-primary underline hover:text-primary/80">info@amaramam.com</a> or call <a href="tel:+917075851158" className="text-primary underline hover:text-primary/80">+91 7075851158</a>. Address: Vijayawada, Andhra Pradesh, India.</p>
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default PrivacyPolicy;
