import Layout from "@/components/Layout";

const TermsAndConditions = () => {
  return (
    <Layout>
      <section className="bg-gradient-to-br from-primary/10 via-background to-teal/5 px-4 py-12 md:py-16">
        <div className="container mx-auto text-center">
          <h1 className="mb-4 font-display text-4xl font-extrabold text-foreground md:text-5xl">Terms & Conditions</h1>
          <p className="mx-auto max-w-2xl text-muted-foreground">Last updated: February 2026</p>
        </div>
      </section>

      <section className="px-4 py-12">
        <div className="container mx-auto max-w-4xl space-y-8 text-foreground">
          <div>
            <h2 className="mb-3 font-display text-2xl font-bold">1. Acceptance of Terms</h2>
            <p className="text-muted-foreground">By accessing and using the Amaramam Skill Hub website and services, you agree to be bound by these Terms & Conditions. If you do not agree with any part of these terms, please do not use our services. These terms apply to all users, including students, visitors, and institutional partners.</p>
          </div>

          <div>
            <h2 className="mb-3 font-display text-2xl font-bold">2. User Obligations</h2>
            <p className="text-muted-foreground">Users must provide accurate and complete information during registration. You are responsible for maintaining the confidentiality of your account credentials. You agree not to share, resell, or redistribute course materials without prior written consent from Amaramam Skill Hub. Any misuse of the platform may result in account suspension or termination.</p>
          </div>

          <div>
            <h2 className="mb-3 font-display text-2xl font-bold">3. Course Access</h2>
            <p className="text-muted-foreground">Upon successful enrollment and payment, you will receive access to the course materials for the specified duration. Course access is personal and non-transferable. Amaramam Skill Hub reserves the right to update, modify, or discontinue any course at any time. Enrolled students will be notified of any significant changes.</p>
          </div>

          <div>
            <h2 className="mb-3 font-display text-2xl font-bold">4. Payment Terms</h2>
            <p className="text-muted-foreground">All course fees are displayed in Indian Rupees (₹) and are inclusive of applicable taxes unless otherwise stated. Payments can be made via UPI, credit/debit cards, net banking, or EMI options where available. Full payment must be completed before course access is granted. Amaramam Skill Hub does not store payment card details on its servers.</p>
          </div>

          <div>
            <h2 className="mb-3 font-display text-2xl font-bold">5. Refund & Cancellation Policy</h2>
            <p className="text-muted-foreground">Please refer to our dedicated <a href="/refund-policy" className="text-primary underline hover:text-primary/80">Refund & Cancellation Policy</a> page for detailed information on eligibility, timelines, and procedures for refunds and cancellations.</p>
          </div>

          <div>
            <h2 className="mb-3 font-display text-2xl font-bold">6. Intellectual Property</h2>
            <p className="text-muted-foreground">All content on the Amaramam Skill Hub website — including text, graphics, logos, course materials, videos, and software — is the property of Amaramam Skill Hub and is protected by intellectual property laws. Unauthorized reproduction, distribution, or use of any content is strictly prohibited.</p>
          </div>

          <div>
            <h2 className="mb-3 font-display text-2xl font-bold">7. Limitation of Liability</h2>
            <p className="text-muted-foreground">Amaramam Skill Hub provides educational content and training services on an "as-is" basis. We do not guarantee specific outcomes such as employment, salary increases, or business results. Our liability is limited to the amount paid by the user for the specific course or service in question. We are not liable for any indirect, incidental, or consequential damages arising from the use of our services.</p>
          </div>

          <div>
            <h2 className="mb-3 font-display text-2xl font-bold">8. Governing Law</h2>
            <p className="text-muted-foreground">These Terms & Conditions are governed by and construed in accordance with the laws of India. Any disputes arising from these terms shall be subject to the exclusive jurisdiction of the courts in Vijayawada, Andhra Pradesh, India.</p>
          </div>

          <div>
            <h2 className="mb-3 font-display text-2xl font-bold">9. Contact Us</h2>
            <p className="text-muted-foreground">If you have any questions about these Terms & Conditions, please contact us at <a href="mailto:info@amaramam.com" className="text-primary underline hover:text-primary/80">info@amaramam.com</a> or call <a href="tel:+917075851158" className="text-primary underline hover:text-primary/80">+91 7075851158</a>.</p>
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default TermsAndConditions;
