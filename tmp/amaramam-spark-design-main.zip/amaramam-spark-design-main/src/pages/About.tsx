import { Target, Eye, Heart, Shield, Zap, Globe, Users } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import Layout from "@/components/Layout";
import { teamMembers, stats } from "@/data/siteData";

const About = () => {
  return (
    <Layout>
      {/* Hero */}
      <section className="bg-gradient-to-br from-primary/10 via-background to-accent/5 px-4 py-12 md:py-16">
        <div className="container mx-auto text-center">
          <h1 className="mb-4 font-display text-4xl font-extrabold text-foreground md:text-5xl">About Amaramam Skill Hub</h1>
          <p className="mx-auto max-w-2xl text-muted-foreground">
            Empowering the next generation of professionals with practical, industry-aligned skills training.
          </p>
        </div>
      </section>

      {/* Mission & Vision */}
      <section className="px-4 py-16">
        <div className="container mx-auto grid gap-10 md:grid-cols-2">
          <div className="flex flex-col justify-center">
            <Badge variant="outline" className="mb-4 w-fit">Our Story</Badge>
            <h2 className="mb-4 font-display text-3xl font-bold text-foreground">From Weekend Workshops to India's Growing Skills Platform</h2>
            <p className="mb-4 text-muted-foreground">
              Founded in 2020, Amaramam Skill Hub was born from a simple belief: every student deserves access to quality, practical skills training — regardless of their background or location.
            </p>
            <p className="text-muted-foreground">
              What started as weekend workshops in a small classroom has grown into a platform trusted by 50+ colleges and 10,000+ learners across India. We bridge the gap between academic knowledge and industry readiness.
            </p>
          </div>
          <div className="grid grid-cols-2 gap-4">
            {[
              { icon: Target, title: "Mission", desc: "To make world-class skills training accessible and affordable for every learner in India." },
              { icon: Eye, title: "Vision", desc: "To become India's most trusted platform for practical education and career transformation." },
              { icon: Heart, title: "Values", desc: "Excellence, inclusivity, practical learning, and community-driven growth." },
              { icon: Globe, title: "Reach", desc: "50+ college partners, 10,000+ learners, and growing across 15+ Indian states." },
            ].map((item) => (
              <Card key={item.title} className="border-none bg-muted/50">
                <CardContent className="p-5">
                  <item.icon className="mb-3 h-8 w-8 text-primary" />
                  <h3 className="mb-1 font-display font-semibold text-foreground">{item.title}</h3>
                  <p className="text-xs text-muted-foreground">{item.desc}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="bg-gradient-to-r from-primary to-teal px-4 py-16 text-primary-foreground">
        <div className="container mx-auto grid grid-cols-2 gap-6 md:grid-cols-4">
          {stats.map((stat) => (
            <div key={stat.label} className="text-center">
              <stat.icon className="mx-auto mb-2 h-10 w-10" />
              <p className="font-display text-3xl font-bold md:text-4xl">{stat.value}</p>
              <p className="text-sm opacity-80">{stat.label}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="px-4 py-16">
        <div className="container mx-auto text-center">
          <h2 className="mb-10 font-display text-3xl font-bold text-foreground">Why Choose Us</h2>
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {[
              { icon: Zap, title: "Industry-Ready Curriculum", desc: "Courses designed with input from hiring managers and tech leads." },
              { icon: Users, title: "Expert Mentors", desc: "Learn from professionals with real-world experience at top companies." },
              { icon: Shield, title: "Certified Programs", desc: "Earn certificates recognized by recruiters and industry partners." },
              { icon: Heart, title: "Community Support", desc: "Join a thriving community of learners, alumni, and mentors." },
            ].map((item) => (
              <Card key={item.title} className="border-none bg-card shadow-md transition-all hover:-translate-y-1 hover:shadow-lg">
                <CardContent className="p-6 text-center">
                  <div className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10">
                    <item.icon className="h-6 w-6 text-primary" />
                  </div>
                  <h3 className="mb-2 font-display font-semibold text-foreground">{item.title}</h3>
                  <p className="text-sm text-muted-foreground">{item.desc}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

    </Layout>
  );
};

export default About;
