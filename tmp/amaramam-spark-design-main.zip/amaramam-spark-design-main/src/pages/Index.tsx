import { Link } from "react-router-dom";
import { ArrowRight, Star, BookOpen, Users, GraduationCap, Award, ChevronRight, Send, CheckCircle, Target, Zap, Shield, Heart, Briefcase } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import Layout from "@/components/Layout";
import { courses, testimonials, stats, pricingPlans, faqs, approachSteps } from "@/data/siteData";
import logo from "@/assets/logo.png";

const Index = () => {
  return (
    <Layout>
      {/* Hero */}
      <section className="relative overflow-hidden px-4 py-24 text-primary-foreground md:py-32 bg-gradient-to-br from-primary via-primary/90 to-teal">
        <div className="container mx-auto text-center">
          <img src={logo} alt="Amaramam Skill Hub" className="mx-auto mb-6 h-20 w-auto drop-shadow-lg brightness-0 invert" />
          <Badge className="mb-6 border-primary-foreground/30 bg-primary-foreground/10 text-primary-foreground">
            🚀 New Batch Starting — Limited Seats Available
          </Badge>
          <h1 className="mx-auto mb-6 max-w-4xl font-display text-4xl font-extrabold leading-tight md:text-6xl lg:text-7xl">
            Amaramam Skill Hub –{" "}
            <span className="bg-gradient-to-r from-accent to-yellow-300 bg-clip-text text-transparent">
              Where Skills Begin
            </span>
          </h1>
          <p className="mx-auto mb-10 max-w-2xl text-lg opacity-90 md:text-xl">
            Empowering 10,000+ learners with real-world, industry-aligned skills in AI, Web Development, Design, Marketing, and more. Your future starts here.
          </p>
          <div className="flex flex-col items-center justify-center gap-4 sm:flex-row">
            <Link to="/courses">
              <Button size="lg" className="bg-accent text-accent-foreground hover:bg-accent/90 text-base px-8">
                Explore Courses <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </Link>
            <Link to="/contact">
              <Button size="lg" className="bg-teal text-teal-foreground hover:bg-teal/90 text-base px-8 font-semibold">
                Contact Us
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="-mt-10 px-4">
        <div className="container mx-auto">
          <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
            {stats.map((stat) => (
              <Card key={stat.label} className="border-none bg-card shadow-xl animate-fade-in-up">
                <CardContent className="flex flex-col items-center p-6 text-center">
                  <div className="mb-3 flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10">
                    <stat.icon className="h-6 w-6 text-primary" />
                  </div>
                  <span className="font-display text-2xl font-bold text-foreground md:text-3xl">{stat.value}</span>
                  <span className="text-sm text-muted-foreground">{stat.label}</span>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="px-4 py-20 md:py-24">
        <div className="container mx-auto text-center">
          <Badge variant="outline" className="mb-4">Why Choose Us</Badge>
          <h2 className="mb-4 font-display text-3xl font-bold text-foreground md:text-4xl">Everything You Need to Succeed</h2>
          <p className="mx-auto mb-14 max-w-2xl text-muted-foreground">
            We bridge the gap between education and employment with practical, industry-aligned training that gets results.
          </p>
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {[
              { icon: Zap, title: "Industry-Aligned Curriculum", desc: "Courses designed with input from hiring managers and tech leads at top companies.", color: "text-primary" },
              { icon: Target, title: "Project-Based Learning", desc: "Work on real-world projects and case studies that build your portfolio.", color: "text-accent" },
              { icon: Users, title: "Expert Mentors", desc: "Learn from professionals with 10+ years of industry experience.", color: "text-teal" },
              { icon: Shield, title: "Certifications & Placements", desc: "Earn recognized certificates and get dedicated placement assistance.", color: "text-primary" },
            ].map((item) => (
              <Card key={item.title} className="group border-none bg-muted/50 transition-all hover:shadow-xl hover:-translate-y-2">
                <CardContent className="p-8 text-center">
                  <div className={`mx-auto mb-5 flex h-16 w-16 items-center justify-center rounded-2xl bg-background shadow-sm ${item.color}`}>
                    <item.icon className="h-8 w-8" />
                  </div>
                  <h3 className="mb-2 font-display text-lg font-semibold text-foreground">{item.title}</h3>
                  <p className="text-sm text-muted-foreground">{item.desc}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Popular Courses */}
      <section className="bg-muted/30 px-4 py-20 md:py-24">
        <div className="container mx-auto">
          <div className="mb-12 flex flex-col items-center justify-between gap-4 sm:flex-row">
            <div>
              <Badge variant="outline" className="mb-3">Popular Courses</Badge>
              <h2 className="font-display text-3xl font-bold text-foreground md:text-4xl">Our Flagship Programs</h2>
              <p className="mt-2 text-muted-foreground">Start learning with our most in-demand courses</p>
            </div>
            <Link to="/courses" className="flex items-center gap-1 font-medium text-primary hover:underline">
              View All Courses <ChevronRight className="h-4 w-4" />
            </Link>
          </div>
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {courses.slice(0, 6).map((course) => (
              <Card key={course.id} className="group overflow-hidden border-none shadow-md transition-all hover:shadow-xl hover:-translate-y-1">
                <div className="relative h-48 overflow-hidden">
                  <img src={course.image} alt={course.title} className="h-full w-full object-cover transition-transform group-hover:scale-105" />
                  <div className="absolute left-3 top-3 flex gap-2">
                    {course.tags.map((tag) => (
                      <Badge key={tag} className="bg-primary/90 text-primary-foreground text-xs">{tag}</Badge>
                    ))}
                  </div>
                </div>
                <CardContent className="p-5">
                  <Badge variant="outline" className="mb-2 text-xs">{course.category}</Badge>
                  <h3 className="mb-1 font-display text-lg font-semibold text-foreground">{course.title}</h3>
                  <p className="mb-3 line-clamp-2 text-sm text-muted-foreground">{course.description}</p>
                  <div className="mb-3 flex items-center gap-3 text-sm text-muted-foreground">
                    <span className="flex items-center gap-1">
                      <Star className="h-4 w-4 fill-accent text-accent" /> {course.rating}
                    </span>
                    <span>•</span>
                    <span>{course.duration}</span>
                    <span>•</span>
                    <span>{course.students.toLocaleString()} students</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="font-display text-lg font-bold text-primary">{course.price}</span>
                    <Button size="sm" className="bg-primary text-primary-foreground hover:bg-primary/90">
                      Enroll Now
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Our Approach: Learn. Apply. Certify. */}
      <section className="px-4 py-20 md:py-24">
        <div className="container mx-auto text-center">
          <Badge variant="outline" className="mb-4">Our Approach</Badge>
          <h2 className="mb-4 font-display text-3xl font-bold text-foreground md:text-4xl">Learn. Apply. Certify.</h2>
          <p className="mx-auto mb-14 max-w-2xl text-muted-foreground">
            Our proven 3-step methodology ensures you don't just learn — you master skills and prove them.
          </p>
          <div className="grid gap-8 md:grid-cols-3">
            {approachSteps.map((step) => (
              <div key={step.step} className="relative">
                <div className="mx-auto mb-6 flex h-20 w-20 items-center justify-center rounded-full bg-gradient-to-br from-primary to-teal text-primary-foreground shadow-lg">
                  <step.icon className="h-9 w-9" />
                </div>
                <span className="mb-2 block font-display text-sm font-bold text-accent">STEP {step.step}</span>
                <h3 className="mb-3 font-display text-2xl font-bold text-foreground">{step.title}</h3>
                <p className="text-muted-foreground">{step.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="bg-gradient-to-br from-primary/5 via-background to-teal/5 px-4 py-20 md:py-24">
        <div className="container mx-auto text-center">
          <Badge variant="outline" className="mb-4">Student Success</Badge>
          <h2 className="mb-4 font-display text-3xl font-bold text-foreground md:text-4xl">What Our Students Say</h2>
          <p className="mx-auto mb-12 max-w-2xl text-muted-foreground">Real stories from real learners who transformed their careers.</p>
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
            {testimonials.map((t, i) => (
              <Card key={i} className="border-none bg-card shadow-md text-left transition-all hover:-translate-y-1 hover:shadow-lg">
                <CardContent className="p-6">
                  <div className="mb-3 flex gap-1">
                    {Array.from({ length: t.rating }).map((_, j) => (
                      <Star key={j} className="h-4 w-4 fill-accent text-accent" />
                    ))}
                  </div>
                  <p className="mb-4 text-sm text-muted-foreground italic leading-relaxed">"{t.quote}"</p>
                  <div className="flex items-center gap-3">
                    <img src={t.avatar} alt={t.name} className="h-11 w-11 rounded-full object-cover ring-2 ring-primary/20" />
                    <div>
                      <p className="text-sm font-semibold text-foreground">{t.name}</p>
                      <p className="text-xs text-muted-foreground">{t.role}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing */}
      <section className="px-4 py-20 md:py-24">
        <div className="container mx-auto text-center">
          <Badge variant="outline" className="mb-4">Pricing</Badge>
          <h2 className="mb-4 font-display text-3xl font-bold text-foreground md:text-4xl">Simple, Transparent Pricing</h2>
          <p className="mx-auto mb-14 max-w-2xl text-muted-foreground">
            Choose the plan that fits your learning goals. No hidden fees.
          </p>
          <div className="grid gap-6 md:grid-cols-3">
            {pricingPlans.map((plan) => (
              <Card
                key={plan.name}
                className={`relative overflow-hidden border-2 text-left transition-all hover:-translate-y-1 hover:shadow-xl ${
                  plan.highlighted
                    ? "border-primary shadow-lg shadow-primary/10"
                    : "border-border"
                }`}
              >
                {plan.highlighted && (
                  <div className="absolute right-0 top-0 rounded-bl-lg bg-primary px-3 py-1 text-xs font-semibold text-primary-foreground">
                    Most Popular
                  </div>
                )}
                <CardContent className="p-8">
                  <h3 className="mb-1 font-display text-xl font-bold text-foreground">{plan.name}</h3>
                  <p className="mb-4 text-sm text-muted-foreground">{plan.description}</p>
                  <div className="mb-6">
                    <span className="font-display text-4xl font-extrabold text-foreground">{plan.price}</span>
                    <span className="ml-1 text-sm text-muted-foreground">/{plan.period}</span>
                  </div>
                  <ul className="mb-8 space-y-3">
                    {plan.features.map((f) => (
                      <li key={f} className="flex items-center gap-2 text-sm text-muted-foreground">
                        <CheckCircle className="h-4 w-4 shrink-0 text-teal" /> {f}
                      </li>
                    ))}
                  </ul>
                  <Button
                    className={`w-full ${
                      plan.highlighted
                        ? "bg-primary text-primary-foreground hover:bg-primary/90"
                        : "bg-muted text-foreground hover:bg-muted/80"
                    }`}
                  >
                    {plan.cta}
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Mission CTA */}
      <section className="bg-gradient-to-r from-primary to-teal px-4 py-20 text-primary-foreground">
        <div className="container mx-auto grid gap-10 md:grid-cols-2 md:items-center">
          <div>
            <h2 className="mb-4 font-display text-3xl font-bold md:text-4xl">Our Mission: Skills for Everyone</h2>
            <p className="mb-4 opacity-90">
              At Amaramam Skill Hub, we believe every student deserves access to quality, practical skills training — regardless of their background or location.
            </p>
            <p className="mb-6 opacity-90">
              We bridge the gap between academic knowledge and industry readiness through expert-led programs, real-world projects, and dedicated career support.
            </p>
            <Link to="/about">
              <Button size="lg" className="bg-accent text-accent-foreground hover:bg-accent/90">
                Learn About Us <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </Link>
          </div>
          <div className="grid grid-cols-2 gap-4">
            {[
              { value: "50+", label: "College Partners" },
              { value: "95%", label: "Satisfaction Rate" },
              { value: "10K+", label: "Students Trained" },
              { value: "500+", label: "Projects Completed" },
            ].map((s) => (
              <div key={s.label} className="rounded-xl bg-primary-foreground/10 p-6 text-center backdrop-blur-sm">
                <p className="font-display text-3xl font-extrabold">{s.value}</p>
                <p className="text-sm opacity-80">{s.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="bg-muted/30 px-4 py-20 md:py-24">
        <div className="container mx-auto max-w-3xl">
          <div className="mb-12 text-center">
            <Badge variant="outline" className="mb-4">FAQ</Badge>
            <h2 className="mb-4 font-display text-3xl font-bold text-foreground md:text-4xl">Frequently Asked Questions</h2>
            <p className="text-muted-foreground">Got questions? We've got answers.</p>
          </div>
          <Accordion type="single" collapsible className="space-y-3">
            {faqs.map((faq, i) => (
              <AccordionItem key={i} value={`faq-${i}`} className="rounded-lg border bg-card px-5 shadow-sm">
                <AccordionTrigger className="font-medium text-left hover:no-underline">{faq.q}</AccordionTrigger>
                <AccordionContent className="text-muted-foreground">{faq.a}</AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      </section>

      {/* Newsletter CTA */}
      <section className="bg-gradient-to-r from-accent to-primary px-4 py-16 text-primary-foreground">
        <div className="container mx-auto text-center">
          <h2 className="mb-4 font-display text-3xl font-bold md:text-4xl">Start Your Learning Journey Today</h2>
          <p className="mx-auto mb-8 max-w-xl opacity-90">
            Get course updates, learning tips, and exclusive offers delivered to your inbox.
          </p>
          <div className="mx-auto flex max-w-md gap-3">
            <Input placeholder="Enter your email" className="border-primary-foreground/20 bg-primary-foreground/10 text-primary-foreground placeholder:text-primary-foreground/60" />
            <Button className="bg-primary-foreground text-primary hover:bg-primary-foreground/90">
              Subscribe <Send className="ml-2 h-4 w-4" />
            </Button>
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default Index;
