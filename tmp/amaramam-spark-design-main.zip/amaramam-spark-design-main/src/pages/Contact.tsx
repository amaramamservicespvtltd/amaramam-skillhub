import { MapPin, Phone, Mail, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import Layout from "@/components/Layout";

const faqs = [
  { q: "How do I enroll in a course?", a: "Simply browse our course catalog, select your course, and click 'Enroll Now'. You'll be guided through the registration process." },
  { q: "Do you offer offline classes?", a: "Yes! We offer both online and offline classes. Check each course listing for availability in your city." },
  { q: "Are certificates provided?", a: "Absolutely. Every course comes with a certificate of completion recognized by our industry partners." },
  { q: "Can my college partner with Amaramam?", a: "Yes! We actively partner with colleges across India. Reach out via this form or email us directly." },
  { q: "What payment methods do you accept?", a: "We accept UPI, credit/debit cards, net banking, and offer EMI options for select courses." },
];

const Contact = () => {
  return (
    <Layout>
      {/* Hero */}
      <section className="bg-gradient-to-br from-teal/10 via-background to-primary/5 px-4 py-12 md:py-16">
        <div className="container mx-auto text-center">
          <h1 className="mb-4 font-display text-4xl font-extrabold text-foreground md:text-5xl">Get in Touch</h1>
          <p className="mx-auto max-w-2xl text-muted-foreground">
            Have a question or ready to start your learning journey? We'd love to hear from you.
          </p>
        </div>
      </section>

      {/* Contact Form + Info */}
      <section className="px-4 py-12">
        <div className="container mx-auto grid gap-10 lg:grid-cols-3">
          <div className="lg:col-span-2">
            <Card className="border-none shadow-lg">
              <CardContent className="space-y-4 p-6">
                <div className="grid gap-4 sm:grid-cols-2">
                  <Input placeholder="Full Name" />
                  <Input placeholder="Email Address" type="email" />
                </div>
                <div className="grid gap-4 sm:grid-cols-2">
                  <Input placeholder="Phone Number" type="tel" />
                  <Select>
                    <SelectTrigger><SelectValue placeholder="Course Interest" /></SelectTrigger>
                    <SelectContent>
                      {["AI/ML", "Web Development", "Digital Marketing", "Design", "Soft Skills", "Other"].map((c) => (
                        <SelectItem key={c} value={c}>{c}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <Textarea placeholder="Your message..." rows={5} />
                <Button className="w-full bg-primary text-primary-foreground hover:bg-primary/90">Send Message</Button>
              </CardContent>
            </Card>
          </div>

          <div className="space-y-4">
            {[
              { icon: MapPin, label: "Address", value: "Vijayawada, Andhra Pradesh, India" },
              { icon: Phone, label: "Phone", value: "+91 7075851158", href: "tel:+917075851158" },
              { icon: Mail, label: "Email", value: "info@amaramam.com", href: "mailto:info@amaramam.com" },
              { icon: Clock, label: "Hours", value: "Mon–Sat: 9 AM – 7 PM" },
            ].map((item) => (
              <Card key={item.label} className="border-none bg-muted/50">
                <CardContent className="flex items-start gap-4 p-5">
                  <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-primary/10">
                    <item.icon className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <p className="font-semibold text-foreground">{item.label}</p>
                    {(item as any).href ? (
                      <a href={(item as any).href} className="whitespace-pre-line text-sm text-muted-foreground hover:text-primary">{item.value}</a>
                    ) : (
                      <p className="whitespace-pre-line text-sm text-muted-foreground">{item.value}</p>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Map Placeholder */}
      <section className="px-4 py-8">
        <div className="container mx-auto">
          <div className="flex h-64 items-center justify-center rounded-xl bg-muted/50 text-muted-foreground">
            <MapPin className="mr-2 h-5 w-5" /> Map embed placeholder — Vijayawada, Andhra Pradesh
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="px-4 py-12">
        <div className="container mx-auto max-w-3xl">
          <h2 className="mb-8 text-center font-display text-3xl font-bold text-foreground">Frequently Asked Questions</h2>
          <Accordion type="single" collapsible>
            {faqs.map((faq, i) => (
              <AccordionItem key={i} value={`faq-${i}`}>
                <AccordionTrigger className="font-medium">{faq.q}</AccordionTrigger>
                <AccordionContent>{faq.a}</AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      </section>
    </Layout>
  );
};

export default Contact;
