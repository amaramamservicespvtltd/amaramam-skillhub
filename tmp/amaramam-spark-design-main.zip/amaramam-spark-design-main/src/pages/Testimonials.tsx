import { Star, Users, GraduationCap, Award, Play } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import Layout from "@/components/Layout";
import { testimonials, stats } from "@/data/siteData";
import testimonialsBanner from "@/assets/testimonials-banner.jpg";

const Testimonials = () => {
  return (
    <Layout>
      {/* Hero */}
      <section className="relative overflow-hidden px-4 py-12 md:py-16">
        <img src={testimonialsBanner} alt="Successful students" className="absolute inset-0 h-full w-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-br from-accent/80 via-background/90 to-primary/60" />
        <div className="container relative mx-auto text-center">
          <h1 className="mb-4 font-display text-4xl font-extrabold text-foreground md:text-5xl">Student Success Stories</h1>
          <p className="mx-auto max-w-2xl text-muted-foreground">
            Hear from learners who transformed their careers with Amaramam Skill Hub.
          </p>
        </div>
      </section>

      {/* Metrics */}
      <section className="px-4 py-12">
        <div className="container mx-auto grid grid-cols-2 gap-6 md:grid-cols-4">
          {stats.map((stat) => (
            <div key={stat.label} className="text-center">
              <stat.icon className="mx-auto mb-2 h-10 w-10 text-primary" />
              <p className="font-display text-3xl font-bold text-foreground md:text-4xl">{stat.value}</p>
              <p className="text-sm text-muted-foreground">{stat.label}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Reviews */}
      <section className="px-4 py-12">
        <div className="container mx-auto">
          <h2 className="mb-8 text-center font-display text-3xl font-bold text-foreground">Student Reviews</h2>
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {testimonials.map((t, i) => (
              <Card key={i} className="border-none bg-muted/50 transition-all hover:-translate-y-1 hover:shadow-lg">
                <CardContent className="p-6">
                  <div className="mb-3 flex gap-1">
                    {Array.from({ length: t.rating }).map((_, j) => (
                      <Star key={j} className="h-4 w-4 fill-accent text-accent" />
                    ))}
                  </div>
                  <p className="mb-4 text-sm text-muted-foreground italic">"{t.quote}"</p>
                  <Badge variant="outline" className="mb-3">{t.course}</Badge>
                  <div className="flex items-center gap-3">
                    <img src={t.avatar} alt={t.name} className="h-10 w-10 rounded-full object-cover" />
                    <div>
                      <p className="text-sm font-semibold text-foreground">{t.name}</p>
                      <p className="text-xs text-muted-foreground">{t.role}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Video Testimonials */}
      <section className="bg-muted/30 px-4 py-16">
        <div className="container mx-auto text-center">
          <h2 className="mb-8 font-display text-3xl font-bold text-foreground">Video Testimonials</h2>
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {["Priya's Journey to Web Development", "Rahul's AI Career Breakthrough", "Ananya's Design Portfolio Story"].map((title, i) => (
              <Card key={i} className="group cursor-pointer overflow-hidden border-none shadow-md transition-all hover:shadow-xl">
                <div className="relative flex h-48 items-center justify-center bg-gradient-to-br from-primary/20 to-teal/20">
                  <div className="flex h-14 w-14 items-center justify-center rounded-full bg-primary/90 text-primary-foreground transition-transform group-hover:scale-110">
                    <Play className="h-6 w-6" />
                  </div>
                </div>
                <CardContent className="p-4">
                  <p className="font-display font-semibold text-foreground">{title}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default Testimonials;
