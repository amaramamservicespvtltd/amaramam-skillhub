import Layout from "@/components/Layout";

const Disclaimer = () => {
  return (
    <Layout>
      <section className="bg-gradient-to-br from-primary/10 via-background to-teal/5 px-4 py-12 md:py-16">
        <div className="container mx-auto text-center">
          <h1 className="mb-4 font-display text-4xl font-extrabold text-foreground md:text-5xl">Disclaimer</h1>
          <p className="mx-auto max-w-2xl text-muted-foreground">Last updated: February 2026</p>
        </div>
      </section>

      <section className="px-4 py-12">
        <div className="container mx-auto max-w-4xl space-y-8 text-foreground">
          <div>
            <h2 className="mb-3 font-display text-2xl font-bold">1. Content Accuracy</h2>
            <p className="text-muted-foreground">The information provided on the Amaramam Skill Hub website is for general informational and educational purposes only. While we strive to keep the content accurate and up-to-date, we make no representations or warranties of any kind, express or implied, about the completeness, accuracy, reliability, or suitability of the information.</p>
          </div>

          <div>
            <h2 className="mb-3 font-display text-2xl font-bold">2. External Links</h2>
            <p className="text-muted-foreground">Our website may contain links to external websites or third-party services. These links are provided for convenience and informational purposes only. Amaramam Skill Hub does not endorse, control, or take responsibility for the content, privacy policies, or practices of any external websites.</p>
          </div>

          <div>
            <h2 className="mb-3 font-display text-2xl font-bold">3. Training Outcomes</h2>
            <p className="text-muted-foreground">Amaramam Skill Hub provides quality education and training to help learners build skills. However, individual outcomes — including job placements, salary increases, or business results — depend on various factors such as individual effort, market conditions, and prior experience. We do not guarantee specific career or financial outcomes from completing our courses.</p>
          </div>

          <div>
            <h2 className="mb-3 font-display text-2xl font-bold">4. Professional Advice</h2>
            <p className="text-muted-foreground">The content on this website does not constitute professional, legal, financial, or career advice. Users should seek appropriate professional counsel for specific questions or decisions related to their personal or professional circumstances.</p>
          </div>

          <div>
            <h2 className="mb-3 font-display text-2xl font-bold">5. Changes to Content</h2>
            <p className="text-muted-foreground">Amaramam Skill Hub reserves the right to update, modify, or remove any content on the website at any time without prior notice. Course offerings, pricing, schedules, and other details are subject to change.</p>
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default Disclaimer;
