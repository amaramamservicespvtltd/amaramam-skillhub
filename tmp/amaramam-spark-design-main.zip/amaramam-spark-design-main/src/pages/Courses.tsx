import { useState } from "react";
import { Star, Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import Layout from "@/components/Layout";
import { courses, categories } from "@/data/siteData";

const Courses = () => {
  const [selectedCategory, setSelectedCategory] = useState("All");
  const [search, setSearch] = useState("");
  const [sort, setSort] = useState("popular");

  const filtered = courses
    .filter((c) => selectedCategory === "All" || c.category === selectedCategory)
    .filter((c) => c.title.toLowerCase().includes(search.toLowerCase()))
    .sort((a, b) => {
      if (sort === "price") return parseInt(a.price.replace(/\D/g, "")) - parseInt(b.price.replace(/\D/g, ""));
      if (sort === "rating") return b.rating - a.rating;
      return b.students - a.students;
    });

  return (
    <Layout>
      {/* Hero */}
      <section className="bg-gradient-to-br from-primary/10 via-background to-teal/5 px-4 py-12 md:py-16">
        <div className="container mx-auto text-center">
          <h1 className="mb-4 font-display text-4xl font-extrabold text-foreground md:text-5xl">Course Catalog</h1>
          <p className="mx-auto max-w-2xl text-muted-foreground">
            Browse 50+ courses designed to equip you with the skills employers demand.
          </p>
        </div>
      </section>

      {/* Filters */}
      <section className="sticky top-16 z-40 border-b bg-background/95 px-4 py-4 backdrop-blur">
        <div className="container mx-auto flex flex-wrap items-center gap-3">
          <div className="relative flex-1 md:max-w-xs">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input placeholder="Search courses..." value={search} onChange={(e) => setSearch(e.target.value)} className="pl-9" />
          </div>
          <div className="flex flex-wrap gap-2">
            {categories.map((cat) => (
              <Button
                key={cat}
                size="sm"
                variant={selectedCategory === cat ? "default" : "outline"}
                onClick={() => setSelectedCategory(cat)}
                className={selectedCategory === cat ? "bg-primary text-primary-foreground" : ""}
              >
                {cat}
              </Button>
            ))}
          </div>
          <Select value={sort} onValueChange={setSort}>
            <SelectTrigger className="w-36">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="popular">Most Popular</SelectItem>
              <SelectItem value="rating">Highest Rated</SelectItem>
              <SelectItem value="price">Lowest Price</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </section>

      {/* Grid */}
      <section className="px-4 py-10">
        <div className="container mx-auto">
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {filtered.map((course) => (
              <Card key={course.id} className="group overflow-hidden border-none shadow-md transition-all hover:shadow-xl hover:-translate-y-1">
                <div className="relative h-48 overflow-hidden">
                  <img src={course.image} alt={course.title} className="h-full w-full object-cover transition-transform group-hover:scale-105" />
                  <div className="absolute left-3 top-3 flex gap-2">
                    {course.tags.map((tag) => (
                      <Badge key={tag} className="bg-primary/90 text-primary-foreground">{tag}</Badge>
                    ))}
                  </div>
                </div>
                <CardContent className="p-5">
                  <Badge variant="outline" className="mb-2">{course.category}</Badge>
                  <h3 className="mb-1 font-display text-lg font-semibold text-foreground">{course.title}</h3>
                  <p className="mb-3 line-clamp-2 text-sm text-muted-foreground">{course.description}</p>
                  <div className="mb-3 flex items-center gap-3 text-sm text-muted-foreground">
                    <span className="flex items-center gap-1"><Star className="h-4 w-4 fill-accent text-accent" /> {course.rating}</span>
                    <span>•</span><span>{course.duration}</span>
                    <span>•</span><span>{course.students.toLocaleString()} students</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="font-display text-lg font-bold text-primary">{course.price}</span>
                    <Button size="sm" className="bg-primary text-primary-foreground hover:bg-primary/90">Enroll Now</Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
          {filtered.length === 0 && (
            <p className="py-12 text-center text-muted-foreground">No courses found. Try adjusting your filters.</p>
          )}
        </div>
      </section>
    </Layout>
  );
};

export default Courses;
