import Layout from "@/components/Layout";

const PlacementPolicy = () => {
  return (
    <Layout>
      <section className="bg-gradient-to-br from-primary/10 via-background to-teal/5 px-4 py-12 md:py-16">
        <div className="container mx-auto text-center">
          <h1 className="mb-4 font-display text-4xl font-extrabold text-foreground md:text-5xl">Placement & Guarantee Policy</h1>
          <p className="mx-auto max-w-2xl text-muted-foreground">Last updated: February 2026</p>
        </div>
      </section>

      <section className="px-4 py-12">
        <div className="container mx-auto max-w-4xl space-y-8 text-foreground">
          <div>
            <h2 className="mb-3 font-display text-2xl font-bold">1. Placement Assistance</h2>
            <p className="text-muted-foreground">Amaramam Skill Hub provides dedicated placement assistance to students enrolled in eligible courses and programs. Our placement support includes resume building, interview preparation, mock interviews, portfolio reviews, and direct referrals to our hiring partner network. Placement assistance is included in our Premium plan and select certification programs.</p>
          </div>

          <div>
            <h2 className="mb-3 font-display text-2xl font-bold">2. No Guaranteed Placement</h2>
            <p className="text-muted-foreground">While we actively work to connect our learners with employment opportunities, Amaramam Skill Hub does not guarantee job placement. Hiring decisions are made solely by employers and depend on factors including the candidate's skills, performance, market conditions, and individual effort during the program.</p>
          </div>

          <div>
            <h2 className="mb-3 font-display text-2xl font-bold">3. Eligibility for Placement Support</h2>
            <p className="text-muted-foreground">To be eligible for placement assistance, students must: successfully complete all course modules and assessments, maintain a minimum attendance of 80%, submit all required projects and assignments, and actively participate in placement preparation activities.</p>
          </div>

          <div>
            <h2 className="mb-3 font-display text-2xl font-bold">4. Our Hiring Partner Network</h2>
            <p className="text-muted-foreground">We maintain partnerships with startups, SMEs, and leading companies across India. Our team regularly engages with employers to understand industry needs and align our training programs accordingly. Students may receive interview opportunities with companies in our network based on their skills and course performance.</p>
          </div>

          <div>
            <h2 className="mb-3 font-display text-2xl font-bold">5. Career Support Beyond Placement</h2>
            <p className="text-muted-foreground">Beyond initial placement, we offer ongoing career support including LinkedIn profile optimization, networking opportunities through alumni events, and access to our job board. Our goal is to support your long-term career growth, not just your first opportunity.</p>
          </div>

          <div>
            <h2 className="mb-3 font-display text-2xl font-bold">6. Contact Us</h2>
            <p className="text-muted-foreground">For questions about our placement services, contact us at <a href="mailto:info@amaramam.com" className="text-primary underline hover:text-primary/80">info@amaramam.com</a> or call <a href="tel:+917075851158" className="text-primary underline hover:text-primary/80">+91 7075851158</a>.</p>
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default PlacementPolicy;
