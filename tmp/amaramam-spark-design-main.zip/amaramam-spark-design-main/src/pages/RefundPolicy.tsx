import Layout from "@/components/Layout";

const RefundPolicy = () => {
  return (
    <Layout>
      <section className="bg-gradient-to-br from-primary/10 via-background to-teal/5 px-4 py-12 md:py-16">
        <div className="container mx-auto text-center">
          <h1 className="mb-4 font-display text-4xl font-extrabold text-foreground md:text-5xl">Refund & Cancellation Policy</h1>
          <p className="mx-auto max-w-2xl text-muted-foreground">Last updated: February 2026</p>
        </div>
      </section>

      <section className="px-4 py-12">
        <div className="container mx-auto max-w-4xl space-y-8 text-foreground">
          <div>
            <h2 className="mb-3 font-display text-2xl font-bold">1. Refund Eligibility</h2>
            <p className="text-muted-foreground">Refund requests are accepted within 7 days of course enrollment, provided that less than 20% of the course content has been accessed. Refunds are not available for courses that have been substantially completed, downloaded, or where certificates have already been issued.</p>
          </div>

          <div>
            <h2 className="mb-3 font-display text-2xl font-bold">2. Cancellation Policy</h2>
            <p className="text-muted-foreground">You may cancel your enrollment at any time by contacting our support team. If cancellation is requested within the 7-day refund window and eligibility criteria are met, a full refund will be processed. Cancellations after 7 days will not be eligible for a refund, but you may transfer your enrollment to another course of equal value.</p>
          </div>

          <div>
            <h2 className="mb-3 font-display text-2xl font-bold">3. Refund Timelines</h2>
            <p className="text-muted-foreground">Once a refund request is approved, the amount will be credited back to your original payment method within 7–10 business days. UPI and wallet refunds may be processed faster (3–5 business days). Bank transfers and credit card refunds may take up to 10 business days depending on your financial institution.</p>
          </div>

          <div>
            <h2 className="mb-3 font-display text-2xl font-bold">4. How to Request a Refund</h2>
            <p className="text-muted-foreground">To request a refund, email us at <a href="mailto:info@amaramam.com" className="text-primary underline hover:text-primary/80">info@amaramam.com</a> with your enrollment ID, registered email, and reason for the refund. Our team will review your request and respond within 2 business days.</p>
          </div>

          <div>
            <h2 className="mb-3 font-display text-2xl font-bold">5. Non-Refundable Items</h2>
            <p className="text-muted-foreground">The following are non-refundable: workshop fees, certification exam fees, downloaded resources, and any course where more than 20% of content has been accessed. Corporate and institutional enrollments are governed by separate agreements.</p>
          </div>

          <div>
            <h2 className="mb-3 font-display text-2xl font-bold">6. Course Transfers</h2>
            <p className="text-muted-foreground">If you are not satisfied with a course, you may request a one-time transfer to another course of equal or lesser value within 14 days of enrollment. Course transfers are subject to availability and approval.</p>
          </div>

          <div>
            <h2 className="mb-3 font-display text-2xl font-bold">7. Contact Us</h2>
            <p className="text-muted-foreground">For refund and cancellation queries, contact us at <a href="mailto:info@amaramam.com" className="text-primary underline hover:text-primary/80">info@amaramam.com</a> or call <a href="tel:+917075851158" className="text-primary underline hover:text-primary/80">+91 7075851158</a>.</p>
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default RefundPolicy;
