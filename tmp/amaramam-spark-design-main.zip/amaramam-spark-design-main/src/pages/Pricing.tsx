import { CheckCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import Layout from "@/components/Layout";
import { pricingPlans, faqs } from "@/data/siteData";

const Pricing = () => {
  return (
    <Layout>
      {/* Hero */}
      <section className="bg-gradient-to-br from-primary/10 via-background to-accent/5 px-4 py-12 md:py-16">
        <div className="container mx-auto text-center">
          <h1 className="mb-4 font-display text-4xl font-extrabold text-foreground md:text-5xl">Pricing Plans</h1>
          <p className="mx-auto max-w-2xl text-muted-foreground">
            Invest in your future with plans designed for every learner.
          </p>
        </div>
      </section>

      {/* Plans */}
      <section className="px-4 py-12">
        <div className="container mx-auto">
          <div className="grid gap-6 md:grid-cols-3">
            {pricingPlans.map((plan) => (
              <Card
                key={plan.name}
                className={`relative overflow-hidden border-2 transition-all hover:-translate-y-1 hover:shadow-xl ${
                  plan.highlighted ? "border-primary shadow-lg shadow-primary/10" : "border-border"
                }`}
              >
                {plan.highlighted && (
                  <div className="absolute right-0 top-0 rounded-bl-lg bg-primary px-3 py-1 text-xs font-semibold text-primary-foreground">
                    Most Popular
                  </div>
                )}
                <CardContent className="p-8">
                  <h3 className="mb-1 font-display text-xl font-bold text-foreground">{plan.name}</h3>
                  <p className="mb-4 text-sm text-muted-foreground">{plan.description}</p>
                  <div className="mb-6">
                    <span className="font-display text-4xl font-extrabold text-foreground">{plan.price}</span>
                    <span className="ml-1 text-sm text-muted-foreground">/{plan.period}</span>
                  </div>
                  <ul className="mb-8 space-y-3">
                    {plan.features.map((f) => (
                      <li key={f} className="flex items-center gap-2 text-sm text-muted-foreground">
                        <CheckCircle className="h-4 w-4 shrink-0 text-teal" /> {f}
                      </li>
                    ))}
                  </ul>
                  <Button className={`w-full ${plan.highlighted ? "bg-primary text-primary-foreground hover:bg-primary/90" : "bg-muted text-foreground hover:bg-muted/80"}`}>
                    {plan.cta}
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="bg-muted/30 px-4 py-16">
        <div className="container mx-auto max-w-3xl">
          <h2 className="mb-8 text-center font-display text-3xl font-bold text-foreground">Questions?</h2>
          <Accordion type="single" collapsible className="space-y-3">
            {faqs.slice(0, 5).map((faq, i) => (
              <AccordionItem key={i} value={`faq-${i}`} className="rounded-lg border bg-card px-5 shadow-sm">
                <AccordionTrigger className="font-medium text-left hover:no-underline">{faq.q}</AccordionTrigger>
                <AccordionContent className="text-muted-foreground">{faq.a}</AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      </section>
    </Layout>
  );
};

export default Pricing;
