import { Link } from "react-router-dom";
import { Facebook, Twitter, Instagram, Linkedin, Youtube, Send, MapPin, Phone, Mail } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

const Footer = () => {
  return (
    <footer className="border-t bg-foreground text-background">
      <div className="container mx-auto px-4 py-12">
        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-5">
          {/* Brand */}
          <div className="lg:col-span-2">
            <Link to="/" className="mb-4 inline-block">
              <span className="font-display text-2xl font-bold text-background">Amaramam Skill Hub</span>
            </Link>
            <p className="mb-4 max-w-xs text-sm opacity-70">
              Empowering learners with real-world skills for a brighter future. Join 10,000+ students transforming their careers.
            </p>
            <div className="mb-4 space-y-2 text-sm opacity-70">
              <p className="flex items-center gap-2"><MapPin className="h-4 w-4" /> Vijayawada, Andhra Pradesh, India</p>
              <p className="flex items-center gap-2"><Phone className="h-4 w-4" /> <a href="tel:+917075851158" className="hover:text-primary">+91 7075851158</a></p>
              <p className="flex items-center gap-2"><Mail className="h-4 w-4" /> <a href="mailto:info@amaramam.com" className="hover:text-primary">info@amaramam.com</a></p>
            </div>
            <div className="flex flex-wrap gap-3">
              {[
                { Icon: Facebook, href: "https://www.facebook.com/profile.php?id=61585622655175" },
                { Icon: Twitter, href: "https://x.com/amaramamskill" },
                { Icon: Instagram, href: "https://www.instagram.com/amaramamskillhub/" },
                { Icon: Linkedin, href: "https://www.linkedin.com/company/110902850/admin/dashboard/" },
                { Icon: Youtube, href: "https://www.youtube.com/@amaramamskillhub" },
              ].map((item, i) => (
                <a key={i} href={item.href} target="_blank" rel="noopener noreferrer" className="rounded-full bg-background/10 p-2 transition-colors hover:bg-primary">
                  <item.Icon className="h-4 w-4" />
                </a>
              ))}
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="mb-4 font-display font-semibold">Quick Links</h4>
            <ul className="space-y-2 text-sm opacity-70">
              {[
                { label: "Home", path: "/" },
                { label: "Courses", path: "/courses" },
                { label: "Programs", path: "/programs" },
                { label: "Pricing", path: "/pricing" },
                { label: "About", path: "/about" },
                { label: "Contact", path: "/contact" },
              ].map((link) => (
                <li key={link.label}>
                  <Link to={link.path} className="transition-colors hover:text-primary hover:opacity-100">{link.label}</Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Legal & Policies */}
          <div>
            <h4 className="mb-4 font-display font-semibold">Legal & Policies</h4>
            <ul className="space-y-2 text-sm opacity-70">
              {[
                { label: "Terms & Conditions", path: "/terms" },
                { label: "Privacy Policy", path: "/privacy-policy" },
                { label: "Refund & Cancellation", path: "/refund-policy" },
                { label: "Disclaimer", path: "/disclaimer" },
                { label: "Placement Policy", path: "/placement-policy" },
              ].map((item) => (
                <li key={item.label}>
                  <Link to={item.path} className="transition-colors hover:text-primary hover:opacity-100">{item.label}</Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Newsletter */}
          <div>
            <h4 className="mb-4 font-display font-semibold">Stay Updated</h4>
            <p className="mb-4 text-sm opacity-70">Subscribe to get the latest courses, tips, and offers.</p>
            <div className="flex gap-2">
              <Input placeholder="Your email" className="border-background/20 bg-background/10 text-background placeholder:text-background/50" />
              <Button size="icon" className="bg-accent text-accent-foreground hover:bg-accent/90">
                <Send className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>

        <div className="mt-10 border-t border-background/10 pt-6 text-center text-sm opacity-50">
          © 2025 Amaramam Skill Hub. All rights reserved.
        </div>
      </div>
    </footer>
  );
};

export default Footer;
