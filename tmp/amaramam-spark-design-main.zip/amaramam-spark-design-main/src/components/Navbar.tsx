import { useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { Menu, X, Phone, ShieldCheck, LogIn } from "lucide-react";
import logo from "@/assets/logo.png";
import { Button } from "@/components/ui/button";

const navLinks = [
  { label: "Home", path: "/" },
  { label: "Courses", path: "/courses" },
  { label: "Programs", path: "/programs" },
  { label: "Pricing", path: "/pricing" },
  { label: "About", path: "/about" },
  { label: "Testimonials", path: "/testimonials" },
  { label: "Blog", path: "/blog" },
  { label: "Contact", path: "/contact" },
];

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);
  const location = useLocation();

  return (
    <>
      {/* Top bar */}
      <div className="hidden border-b border-border/50 bg-primary text-primary-foreground md:block">
        <div className="container mx-auto flex items-center justify-between px-4 py-1.5 text-xs">
          <span className="opacity-80">📞 <a href="tel:+917075851158">+91 7075851158</a> | ✉️ <a href="mailto:info@amaramam.com">info@amaramam.com</a></span>
          <div className="flex items-center gap-4">
            <a href="#" className="flex items-center gap-1 opacity-80 transition-opacity hover:opacity-100">
              <ShieldCheck className="h-3.5 w-3.5" /> Verify Certificate
            </a>
            <a href="#" className="flex items-center gap-1 opacity-80 transition-opacity hover:opacity-100">
              <LogIn className="h-3.5 w-3.5" /> Login
            </a>
            <a
              href="https://wa.me/917075851158"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1 rounded bg-primary-foreground/15 px-2 py-0.5 transition-colors hover:bg-primary-foreground/25"
            >
              <Phone className="h-3.5 w-3.5" /> WhatsApp Chat
            </a>
          </div>
        </div>
      </div>

      {/* Main nav */}
      <nav className="sticky top-0 z-50 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container mx-auto flex h-16 items-center justify-between px-4">
          <Link to="/" className="flex items-center gap-2">
            <img src={logo} alt="Amaramam Skill Hub" className="h-14 w-auto md:h-16" />
          </Link>

          {/* Desktop nav */}
          <div className="hidden items-center gap-0.5 lg:flex">
            {navLinks.map((link) => (
              <Link
                key={link.path}
                to={link.path}
                className={`rounded-md px-3 py-2 text-sm font-medium transition-colors hover:bg-muted hover:text-primary ${
                  location.pathname === link.path ? "text-primary" : "text-muted-foreground"
                }`}
              >
                {link.label}
              </Link>
            ))}
            <Link to="/contact">
              <Button size="sm" className="ml-2 bg-accent text-accent-foreground hover:bg-accent/90">
                Enroll Now
              </Button>
            </Link>
          </div>

          {/* Mobile toggle */}
          <button className="lg:hidden" onClick={() => setIsOpen(!isOpen)}>
            {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>

        {/* Mobile menu */}
        {isOpen && (
          <div className="border-t bg-background px-4 py-4 lg:hidden">
            {navLinks.map((link) => (
              <Link
                key={link.path}
                to={link.path}
                onClick={() => setIsOpen(false)}
                className={`block rounded-md px-3 py-2 text-sm font-medium transition-colors hover:bg-muted ${
                  location.pathname === link.path ? "text-primary" : "text-muted-foreground"
                }`}
              >
                {link.label}
              </Link>
            ))}
            <div className="mt-3 flex flex-col gap-2 border-t pt-3">
              <a href="#" className="flex items-center gap-2 px-3 py-1.5 text-sm text-muted-foreground">
                <ShieldCheck className="h-4 w-4" /> Verify Certificate
              </a>
              <a href="#" className="flex items-center gap-2 px-3 py-1.5 text-sm text-muted-foreground">
                <LogIn className="h-4 w-4" /> Login
              </a>
            </div>
            <Link to="/contact" onClick={() => setIsOpen(false)}>
              <Button size="sm" className="mt-2 w-full bg-accent text-accent-foreground hover:bg-accent/90">
                Enroll Now
              </Button>
            </Link>
          </div>
        )}
      </nav>
    </>
  );
};

export default Navbar;
